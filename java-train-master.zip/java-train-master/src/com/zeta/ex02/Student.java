package com.zeta.ex02;

/**
 * 作业题：完成第3讲讲义的最后一道练习题
 */
public class Student {

}
