package com.zeta.ex01;

public class Main {

    public static void main(String[] args) {
	    // 在这里可以编写自己的主程序代码，对作业代码进行验证。这里的代码作为自己测试，不会参与成绩评定。

    }
}
